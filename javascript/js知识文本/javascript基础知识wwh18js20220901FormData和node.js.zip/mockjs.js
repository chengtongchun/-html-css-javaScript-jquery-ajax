const Mock = require('mockjs');
const data = Mock.mock({
    'students|40':
        [{
            id: '@increment()',
            name: '@name',
            address: '@city(true)',
            idcard: "@id()",
            modi:"@date(yyyy-MM-dd)",
            "grade|1":["大学","大专","高中","xiaoxue"],
            "socre|.2":33.12345,
        }]
});
console.log(data);