//当初始的 HTML 文档被完全加载和解析完成之后，DOMContentLoaded 事件被触发，而无需等待样式表、图像和子框架的完全加载。
window.addEventListener("DOMContentLoaded", init);
var bannerTimeId = null;
var bannerIdx = 0;

function init() {
  console.log("加载完成");
  //移动端导航按钮
  var menuButton = document.querySelector("header .button");
  menuButton.addEventListener("click", menuButtonClick);

  //banner
  var banner = document.querySelector(".banner-content");
  banner.addEventListener("mouseover", bannerOver);
  banner.addEventListener("mouseout", bannerOut);
  banner.addEventListener("transitionend", bannerTransitionend);

  //滚动条
  document.addEventListener("scroll", scroll);

  //监听banner左右切换
  var bannerLeft = document.querySelector(".banner .pre");
  var bannerRight = document.querySelector(".banner .next");
  bannerLeft.addEventListener("click", bannerLeftClick);
  bannerRight.addEventListener("click", bannerRightClick);
  // console.log(bannerLeft, bannerRight);

  //处理banner小图标点击事件
  var circles = document.querySelectorAll(".img-idx li");
  circles.forEach(function (el, idx) {
    el.addEventListener("click", circleClick(idx));
  });

  // banner.style.transform='translateX(-100%)'
  bannerAutoPlay();
}

function menuButtonClick(){
  var nav = document.querySelector("header .nav");
  nav.classList.toggle('active')
}

function bannerOver(e) {
  // console.log(111,e,this)
  clearInterval(bannerTimeId);
}
function bannerOut() {
  bannerAutoPlay();
}

function bannerLeftClick() {
  clearInterval(bannerTimeId);
  bannerIdx--;
  moveImg();
}

function bannerRightClick() {
  clearInterval(bannerTimeId);
  bannerIdx++;
  moveImg();
}

function nextImg() {
  bannerIdx++;
  moveImg();
}

function moveImg() {
  var banner = document.querySelector(".banner-content");
  var bannerItems = banner.querySelectorAll(".item");
  if (bannerIdx == bannerItems.length) {
    bannerIdx = 0;
  } else if (bannerIdx < 0) {
    bannerIdx = banner.querySelectorAll(".item").length - 1;
  }
  // var bannerItem = bannerItems[bannerIdx];
  // bannerItem.style.transition='transform 1.2s'

  banner.style.transform = "translate3d(-" + bannerIdx * 100 + "%,0,0)";
  // console.log("bannerIdx:", bannerIdx);
}

function bannerAutoPlay() {
  bannerTimeId = setInterval(nextImg, 3000);
}
function bannerTransitionend() {
  // console.log('动画结束')

  //处理banner小图标索引
  var circles = document.querySelectorAll(".img-idx li");
  circles.forEach(function (el) {
    el.classList.remove("active");
  });
  circles[bannerIdx].classList.add("active");
}

//监听滚动条位置
function scroll(e) {
  // console.log(e);
  var dh1 = document.querySelector("#dh-1");
  var dh2 = document.querySelector("#dh-2");

  if (isShow(dh1)) {
    dh1.classList.add("active");
  } else dh1.classList.remove("active");

  if (isShow(dh2)) {
    dh2.classList.add("active");
  } else dh2.classList.remove("active");
}

//判断元素在可视区内
function isShow(el) {
  // console.log(el.getBoundingClientRect().top,window.scrollY);
  // console.log(el.offsetHeight,el.getBoundingClientRect().height)
  return (
    el.getBoundingClientRect().top > 0 &&
    el.getBoundingClientRect().top <=
      window.screen.availHeight - el.getBoundingClientRect().height
  );
}

function circleClick(idx) {
  return function () {
    // console.log(idx);
    bannerIdx = idx;
    clearInterval(bannerTimeId);
    moveImg();
  };
}
